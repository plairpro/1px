'use client';
import {useEffect,useRef,useState} from 'react';
const colors=['#171717','#6b7280','#ffffff','#ed4545','#ff8243','#f7ca45','#9acb62','#308d69','#3abfc1','#4487df','#6b5bd2','#b579da','#ee87b4','#8b6149'];
type State={signedIn:boolean,mine:null|{cell:number,color:string},total:number,filled:number};
export default function Home(){
 const canvas=useRef<HTMLCanvasElement>(null), pixels=useRef(new Map<number,string>()),version=useRef(0),busy=useRef(false);
 const [state,setState]=useState<State>({signedIn:false,mine:null,total:0,filled:0}),[ready,setReady]=useState(false),[color,setColor]=useState('#ff8243'),[selected,setSelected]=useState<number|null>(null),[zoom,setZoom]=useState(1),[error,setError]=useState(''),[saving,setSaving]=useState(false);
 function draw(){const c=canvas.current;if(!c)return;const ctx=c.getContext('2d')!;ctx.fillStyle='#fff';ctx.fillRect(0,0,1920,1080);pixels.current.forEach((col,cell)=>{ctx.fillStyle=col;ctx.fillRect(cell%192*10,Math.floor(cell/192)*10,10,10)});}
 async function sync(){if(busy.current)return;busy.current=true;try{const r=await fetch('/api/canvas?since='+version.current);if(!r.ok)throw Error();const d=await r.json() as State & {pixels:{id:number,cell:number,color:string}[]};for(const p of d.pixels){pixels.current.set(p.cell,p.color);version.current=Math.max(version.current,p.id)}setState(d);setReady(true);setError('');draw()}catch{setError('Не удалось обновить полотно. Попробуем снова.')}finally{busy.current=false}}
 useEffect(()=>{sync();const id=setInterval(()=>{if(!document.hidden)sync()},15000);return()=>clearInterval(id)},[]);
 async function paint(){if(selected===null||saving)return;setSaving(true);setError('');try{const r=await fetch('/api/canvas',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({cell:selected,color})});const d=await r.json() as {error?:string};if(!r.ok)throw Error(d.error);await sync();setSelected(null)}catch(e){setError(e instanceof Error?e.message:'Не удалось сохранить')}finally{setSaving(false)}}
 const x=selected===null?0:selected%192,y=selected===null?0:Math.floor(selected/192);
 return <main>
 <div className="counter">Закрашено пикселей: <span>{ready?state.filled.toLocaleString('ru'):'—'}</span></div>
 <section className="frame" aria-label="Полотно">
 <div className="viewport"><div className="art" style={{width:zoom*100+'%'}}><canvas ref={canvas} width={1920} height={1080} aria-label="Выбрать пиксель" onClick={e=>{if(!ready||state.mine||saving)return;const r=e.currentTarget.getBoundingClientRect();setSelected(Math.min(107,Math.floor((e.clientY-r.top)/r.height*108))*192+Math.min(191,Math.floor((e.clientX-r.left)/r.width*192)))}}/>{selected!==null&&<div className="selection" style={{left:x/192*100+'%',top:y/108*100+'%',width:100/192+'%',height:100/108+'%',background:color}}/>}</div></div>
 {selected===null&&<div className="signature"><img src="/qr.svg" width="128" height="128" alt="QR-код полотна"/><p>Ваш пиксель —<br/>часть общей картины.</p></div>}
 <div className="zoom"><button aria-label="Уменьшить" disabled={zoom===1} onClick={()=>setZoom(Math.max(1,zoom-1))}>−</button><button aria-label="Приблизить" disabled={zoom===8} onClick={()=>setZoom(Math.min(8,zoom+1))}>+</button></div>
 </section>
 {selected!==null&&!state.mine&&<div className="editor"><div className="palette">{colors.map(c=><button key={c} title={c} aria-label={'Цвет '+c} aria-pressed={color===c} className={color===c?'active':''} style={{background:c}} onClick={()=>setColor(c)}/>)}<label className="custom" title="Другой цвет">+<input aria-label="Свой цвет" type="color" value={color} onChange={e=>setColor(e.target.value)}/></label></div><div className="actions">{state.signedIn?<button className="paint" disabled={saving} onClick={paint}>{saving?'…':'Закрасить'}</button>:<a className="paint" href="/signin-with-chatgpt?return_to=/" target="_top">Войти и закрасить</a>}<button className="close" aria-label="Отменить выбор" onClick={()=>setSelected(null)}>×</button></div></div>}
 {error&&<p className="error" role="alert">{error}</p>}
 </main>
}

import { env } from 'cloudflare:workers';
export const dynamic = 'force-dynamic';
const reply=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
export async function GET(request:Request){
 const db=env.DB!; const user=request.headers.get('oai-authenticated-user-id');
 const since=Math.max(0,Number(new URL(request.url).searchParams.get('since'))||0);
 const rows=await db.prepare('SELECT s.id,s.cell,s.color FROM strokes s JOIN (SELECT cell,MAX(id) id FROM strokes WHERE id > ? GROUP BY cell) latest ON s.id=latest.id').bind(since).all();
 const count=await db.prepare('SELECT COUNT(*) total, COUNT(DISTINCT cell) filled, COALESCE(MAX(id),0) version FROM strokes').first();
 const mine=user?await db.prepare('SELECT cell,color FROM strokes WHERE user=?').bind(user).first():null;
 return reply({pixels:rows.results,...count,signedIn:!!user,mine});
}
export async function POST(request:Request){
 if(request.headers.get('origin')!==new URL(request.url).origin)return reply({error:'Недопустимый запрос'},403);
 const user=request.headers.get('oai-authenticated-user-id');
 if(!user)return reply({error:'Войдите, чтобы оставить свой пиксель'},401);
 let body;try{body=await request.json() as {cell:number,color:string}}catch{return reply({error:'Некорректный запрос'},400)}
 if(!Number.isInteger(body.cell)||body.cell<0||body.cell>=20736||!/^#[0-9a-fA-F]{6}$/.test(body.color))return reply({error:'Выберите клетку и цвет'},400);
 const result=await env.DB!.prepare('INSERT INTO strokes(user,cell,color) VALUES(?,?,?) ON CONFLICT(user) DO NOTHING').bind(user,body.cell,body.color.toLowerCase()).run();
 if(!result.meta.changes)return reply({error:'Вы уже оставили свой пиксель'},409);
 return reply({ok:true});
}

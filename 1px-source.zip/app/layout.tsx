import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'Один пиксель — общее полотно',description:'Одно полотно. Один цвет. Один след от каждого.',icons:{icon:'/favicon.svg'}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="ru"><body>{children}</body></html>}

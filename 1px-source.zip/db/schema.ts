import { sqliteTable, integer, text, index } from 'drizzle-orm/sqlite-core';
export const strokes = sqliteTable('strokes', {
 id: integer('id').primaryKey({autoIncrement:true}),
 user: text('user').notNull().unique(),
 cell: integer('cell').notNull(),
 color: text('color').notNull(),
}, t => [index('cell_idx').on(t.cell)]);

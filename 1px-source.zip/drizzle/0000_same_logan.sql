CREATE TABLE `strokes` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`user` text NOT NULL,
	`cell` integer NOT NULL,
	`color` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `strokes_user_unique` ON `strokes` (`user`);--> statement-breakpoint
CREATE INDEX `cell_idx` ON `strokes` (`cell`);